const loginPage = document.getElementById("loginPage");
const chatPage = document.getElementById("chatPage");
const emailInput = document.getElementById("email");
const passwordInput = document.getElementById("password");
const loginButton = document.getElementById("loginButton");
const userQuery = document.getElementById("userQuery");
const responseArea = document.getElementById("responseArea");
const followUpQuery = document.getElementById("followUpQuery");
const sendFollowUp = document.getElementById("sendFollowUp");

// Check if the user is logged in
chrome.storage.local.get(["token"], async (data) => {
  if (data.token) {
    try {
      const isValid = await verifyToken(data.token);
      if (isValid) {
        showChatPage();
        return;
      }
    } catch {
      console.error("Token invalid. Redirecting to login.");
    }
  }
  showLoginPage();
});

// Handle login
loginButton.addEventListener("click", async () => {
  const email = emailInput.value.trim();
  const password = passwordInput.value.trim();

  if (!email || !password) {
    alert("Please fill out both fields.");
    return;
  }

  try {
    const res = await fetch("http://localhost:3000/api/v1/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });
    const result = await res.json();

    if (result.token) {
      chrome.storage.local.set({ token: result.token });
      showChatPage();
    } else {
      alert("Login failed.");
    }
  } catch (error) {
    console.error("Error during login:", error);
  }
});

// Capture selected text from content script
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "setQuery") {
    userQuery.value = message.text;
    sendQueryToBackend(message.text);
  }
});

// Send the query to the backend
async function sendQueryToBackend(query) {
  responseArea.textContent = "Loading...";
  const token = await getToken();

  try {
    const res = await fetch("http://localhost:3000/api/v1/new", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ message: query, class_name: "null" }),
    });

    const result = await res.json();
    displayResponse(result.messages.at(-1).content);
  } catch (error) {
    console.error("Error sending query:", error);
    responseArea.textContent = "Error retrieving response.";
  }
}

// Handle follow-up questions
sendFollowUp.addEventListener("click", async () => {
  const followUp = followUpQuery.value.trim();
  if (!followUp) return;

  await sendQueryToBackend(followUp);
  followUpQuery.value = "";
});

// Display the backend response
function displayResponse(answer) {
  responseArea.innerHTML = `<strong>Answer:</strong> ${answer}`;
}

// Utility functions
async function getToken() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["token"], (data) => resolve(data.token));
  });
}

async function verifyToken(token) {
  const res = await fetch("http://localhost:3000/api/v1/verify-token", {
    headers: { Authorization: `Bearer ${token}` },
  });
  return res.status === 200;
}

function showLoginPage() {
  loginPage.classList.remove("hidden");
  chatPage.classList.add("hidden");
}

function showChatPage() {
  loginPage.classList.add("hidden");
  chatPage.classList.remove("hidden");
}
