chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "textSelected") {
      chrome.runtime.sendMessage({ action: "setQuery", text: message.text });
    }
  });
  